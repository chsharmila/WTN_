package com.wipro.inheritance;

public class Person {
	String member;
	public String getMember() {
		return member;
	}
	public void setMember(String member) {
		this.member = member;
	}
}
