package com.wipro.inheritance;

public class Animal {
	void eat()
	{
		System.out.println("Method Eat");
	}
	void play()
	{
		System.out.println("Method Play");	
	}
}
