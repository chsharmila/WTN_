package com.wipro.languagebasics;

public class EX1 {
	public static void main(String args[])
	{
		String s1=args[0];
		String s2=args[1];
		System.out.println(s1+" Technologies "+s2);
	}
}
