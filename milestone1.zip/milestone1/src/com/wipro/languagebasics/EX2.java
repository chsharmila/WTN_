package com.wipro.languagebasics;

public class EX2 {
	public static void main(String args[])
	{
		String s3=args[2];
		System.out.println("Welcome "+s3);
	}
}
