package com.wipro.languagebasics;

public class EX3 {
	public static void main(String args[])
	{
		int a=Integer.parseInt(args[3]);
		int b=Integer.parseInt(args[4]);
		System.out.println("The sum of "+a+" and "+b+" is "+(a+b));
	}
}
