package com.wipro.encapusaltion;

public class Author {
	public static String name;
	public static String email;
	public static char gender;
	Author(String name,String email,char gender){
	this.name=name;
	this.email=email;
	this.gender=gender;
	}
	public String getName() {
	return name;
	}
	public void setName(String name) {
	this.name = name;
	}
	public String getEmail() {
	return email;
	}
	public void setEmail(String email) {
	this.email = email;
	}
	public char getGender() {
	return gender;
	}
	public void setGender(char gender) {
	this.gender = gender;
	}
}
