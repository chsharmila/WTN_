package com.wipro.flowcontrolstatements;

public class EX4A {
	public static void main(String[] args) {
		char a='e';
		char b='a';
		if(b>a)
		{
			System.out.println(""+a+" "+b);
		}
		else
		{
			System.out.println(""+b+" "+a);

		}
		
	}
}
