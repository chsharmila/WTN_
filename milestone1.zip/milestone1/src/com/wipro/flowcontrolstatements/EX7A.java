package com.wipro.flowcontrolstatements;

public class EX7A {
	public static void main(String[] args) {
		char a='D';
		if(a>='a'&&a<='z')
		{
			System.out.println("a-->"+Character.toUpperCase(a));
		}
		else
		{	
			System.out.println("a-->"+Character.toLowerCase(a));
		}
	}
}
