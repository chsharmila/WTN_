package com.wipro.flowcontrolstatements;

public class EX10A {
	public static void main(String[] args) {
		System.out.print("1");
		for(int i=2;i<=10;i++)
		{
			System.out.print("	"+i);
		}
	}
}
